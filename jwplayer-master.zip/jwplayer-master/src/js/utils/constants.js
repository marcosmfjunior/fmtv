define([], function() {
    return {
        repo : 'http://ssl.p.jwpcdn.com/player/v/',
        SkinsIncluded : ['seven'],
        SkinsLoadable : ['beelden', 'bekle', 'five', 'glow', 'roundster', 'six', 'stormtrooper', 'vapor']
    };
});

define([], function() {
    // This is replaced by compiler
    return __BUILD_VERSION__;
});


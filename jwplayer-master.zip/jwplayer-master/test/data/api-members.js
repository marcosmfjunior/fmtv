define({
    id: '',
    version: '',
    _qoe: {},
    utils: {},
    Events: {},
    _: function() {}
});

define({
    tagged : {
        file : 'sample',
        type : 'aac'
    }
});
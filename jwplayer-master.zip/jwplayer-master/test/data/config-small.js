define({
    file: 'http://playertest.longtailvideo.com/mp4.mp4'
});

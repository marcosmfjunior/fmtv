angular.module('starter.controllers', [])

.controller('RadioCtrl',function($scope) {})

.controller('TvCtrl',function($scope) {})

.controller('NewsCtrl',function(News,$scope) {
 
  News.getNoticias().success(function(data){
    $scope.rssTitle = data.responseData.feed.title;
    $scope.rssUrl = data.responseData.feed.feedUrl;
    $scope.rssSiteUrl = data.responseData.feed.link;
    $scope.entries = data.responseData.feed.entries;
    window.localStorage["noticias"] = angular.toJson(data.responseData.feed.entries);
  });

  $scope.browse = function(v) {
    News.getNoticia(v).success(function(data){
   // console.log(data);
    });
   // DetalheNoticia.setItem(v.$$hashKey);
  }
  
})

.controller('NewsDetailCtrl', function($scope, $stateParams, News) {
  console.log('teste');
  
})

.controller('EventosCtrl',function($scope) {});

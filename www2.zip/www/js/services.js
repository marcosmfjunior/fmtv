angular.module('starter.services', [])

.factory('News', ['$http', function($http) {

    var urlBase = '//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=15&callback=JSON_CALLBACK&q=http://www.furg.br/bin/rss/noticias.php';
    var dados = {};

    dados.getNoticias = function () {     
      return $http.jsonp(urlBase);
    };

    dados.getNoticia = function (id) {
      var noticias = angular.fromJson(localStorage.getItem("noticias"));  
      noticias = noticias.splice(id, 1);
      //console.log(noticias);
    };   

    return dados;


}]);
